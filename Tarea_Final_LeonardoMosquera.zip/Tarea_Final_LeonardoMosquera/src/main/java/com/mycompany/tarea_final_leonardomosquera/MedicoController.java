/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.tarea_final_leonardomosquera;

import ClasesDAO.EspecialidadDAO;
import ClasesDAO.MedicoDAO;
import Entidades.Especialidad;
import Entidades.Medico;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;

/**
 *
 * @author leofr
 */
@WebServlet(name = "MedicoController", urlPatterns = {"/MedicoController"})
public class MedicoController extends HttpServlet {

    private MedicoDAO medicoDAO = new MedicoDAO();
    private EspecialidadDAO especialidadDAO = new EspecialidadDAO();
    
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet MedicoController</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet MedicoController at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        
        String accion = request.getParameter("accion");
        if (accion == null) accion = "listar"; // Acción por defecto
        
        switch (accion) {
            case "listar":
                listarMedicos(request, response);
                break;
            case "mostrarFormRegistro":
                cargarDatosFormulario(request, response); // Carga Especialidades
                request.getRequestDispatcher("/MedicosJSP/registrarMedico.jsp").forward(request, response);
                break;
            case "obtener":
                obtenerMedicoParaEditar(request, response);
                break;
            case "eliminar":
                eliminarMedico(request, response);
                break;
            default:
                listarMedicos(request, response);
        }
        
        
        
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        
        String accion = request.getParameter("accion");
        
        if (accion != null) {
            switch (accion) {
                case "registrar":
                    registrarMedico(request, response);
                    break;
                case "actualizar":
                    actualizarMedico(request, response);
                    break;
            }
        }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void listarMedicos(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        List<Medico> lista = medicoDAO.listarMedicos();
        request.setAttribute("listaMedicos", lista);
        request.getRequestDispatcher("/MedicosJSP/listarMedico.jsp").forward(request, response);
    }
    
    private void cargarDatosFormulario(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Necesario para el ComboBox de Especialidades
        List<Especialidad> listaEspecialidades = especialidadDAO.listarEspecialidades();
        request.setAttribute("listaEspecialidades", listaEspecialidades);
    }

    private void registrarMedico(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 1. Obtener datos
        String nombre = request.getParameter("nombre");
        int idespecialidad = Integer.parseInt(request.getParameter("idespecialidad"));
        
        // 2. Crear objeto y llamar DAO
        Medico m = new Medico();
        m.setNombres(nombre);
        m.setIdespecialidad(idespecialidad);
        
        int resultado = medicoDAO.insertarMedico(m);
        String mensaje = (resultado > 0) ? "Médico registrado exitosamente." : "Error al registrar médico.";
        
        // 3. Redireccionar al listado
        response.sendRedirect("MedicoController?mensaje=" + mensaje);
    }
    
    private void obtenerMedicoParaEditar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int id = Integer.parseInt(request.getParameter("id"));
        Medico medico = medicoDAO.obtenerMedico(id);
        
        request.setAttribute("medicoEditar", medico);
        cargarDatosFormulario(request, response); // Recargar ComboBox
        
        request.getRequestDispatcher("/MedicosJSP/editarMedico.jsp").forward(request, response);
    }
    
    private void actualizarMedico(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 1. Obtener datos
        int idmedico = Integer.parseInt(request.getParameter("idmedico"));
        String nombre = request.getParameter("nombre");
        int idespecialidad = Integer.parseInt(request.getParameter("idespecialidad"));
        
        // 2. Crear objeto y llamar DAO
        Medico m = new Medico();
        m.setIdmedico(idmedico);
        m.setNombres(nombre);
        m.setIdespecialidad(idespecialidad);
        
        int resultado = medicoDAO.actualizarMedico(m);
        String mensaje = (resultado > 0) ? "Médico actualizado exitosamente." : "Error al actualizar médico.";
        
        // 3. Redireccionar al listado
        response.sendRedirect("MedicoController?mensaje=" + mensaje);
    }
    
    private void eliminarMedico(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int id = Integer.parseInt(request.getParameter("id"));
        int resultado = medicoDAO.eliminarMedico(id);
        
        String mensaje = (resultado > 0) ? "Médico eliminado correctamente." : "Error: No se pudo eliminar (posiblemente tiene citas asociadas).";
        
        response.sendRedirect("MedicoController?mensaje=" + mensaje);
    }
    
    
}
