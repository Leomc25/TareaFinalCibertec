/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.tarea_final_leonardomosquera;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import Entidades.*;
import ClasesDAO.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 *
 * @author leofr
 */
@WebServlet(name = "PacienteController", urlPatterns = {"/PacienteController"})
public class PacienteController extends HttpServlet {
    
    private PacienteDAO pacienteDAO = new PacienteDAO();
    private SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet PacienteController</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet PacienteController at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
       // processRequest(request, response);
        String accion = request.getParameter("accion");
        if (accion == null) accion = "listar";
        
        switch (accion) {
            case "listar":
                listarPacientes(request, response);
                break;
            case "mostrarFormRegistro":
                request.getRequestDispatcher("/PacienteJSP/registrarPaciente.jsp").forward(request, response);
                break;
            case "obtener":
                obtenerPacienteParaEditar(request, response);
                break;
            case "eliminar":
                eliminarPaciente(request, response);
                break;
            default:
                listarPacientes(request, response);
        }
        
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        
        String accion = request.getParameter("accion");
        
        if (accion != null) {
            switch (accion) {
                case "registrar":
                    registrarPaciente(request, response);
                    break;
                case "actualizar":
                    actualizarPaciente(request, response);
                    break;
            }
        }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    
    
    private void listarPacientes(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        List<Paciente> lista = pacienteDAO.listarPacientes();
        request.setAttribute("listaPacientes", lista);
      //  request.getRequestDispatcher("/JSP/listarPaciente.jsp").forward(request, response);
        request.getRequestDispatcher("/PacienteJSP/listarPaciente.jsp").forward(request, response);
    }

    private void registrarPaciente(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String mensaje = "Error al registrar paciente.";
        try {
            // 1. Obtener datos
            String nombre = request.getParameter("nombre");
            String fechaStr = request.getParameter("nacimiento"); // Formato yyyy-MM-dd
            Date nacimiento = formatoFecha.parse(fechaStr); // Parseo de String a java.util.Date
            
            // 2. Crear objeto y llamar DAO
            Paciente p = new Paciente();
            p.setNombre(nombre);
            p.setNacimiento(nacimiento);
            
            int resultado = pacienteDAO.insertarPaciente(p);
            mensaje = (resultado > 0) ? "Paciente registrado exitosamente." : mensaje;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // 3. Redireccionar al listado
        response.sendRedirect("PacienteController?mensaje=" + mensaje);
    }

    private void obtenerPacienteParaEditar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int id = Integer.parseInt(request.getParameter("id"));
        Paciente paciente = pacienteDAO.obtenerPaciente(id);
        
        request.setAttribute("pacienteEditar", paciente);
        request.getRequestDispatcher("/PacienteJSP/editarPaciente.jsp").forward(request, response);
    }

    private void actualizarPaciente(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String mensaje = "Error al actualizar paciente.";
        try {
            // 1. Obtener datos
            int idpaciente = Integer.parseInt(request.getParameter("idpaciente"));
            String nombre = request.getParameter("nombre");
            String fechaStr = request.getParameter("nacimiento");
            Date nacimiento = formatoFecha.parse(fechaStr);
            
            // 2. Crear objeto y llamar DAO
            Paciente p = new Paciente();
            p.setIdpaciente(idpaciente);
            p.setNombre(nombre);
            p.setNacimiento(nacimiento);
            
            int resultado = pacienteDAO.actualizarPaciente(p);
            mensaje = (resultado > 0) ? "Paciente actualizado exitosamente." : mensaje;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // 3. Redireccionar al listado
        response.sendRedirect("PacienteController?mensaje=" + mensaje);
    }

    private void eliminarPaciente(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int id = Integer.parseInt(request.getParameter("id"));
        int resultado = pacienteDAO.eliminarPaciente(id);
        
        String mensaje = (resultado > 0) ? "Paciente eliminado correctamente." : "Error: No se pudo eliminar (posiblemente tiene citas asociadas).";
        
        response.sendRedirect("PacienteController?mensaje=" + mensaje);
    }
}
