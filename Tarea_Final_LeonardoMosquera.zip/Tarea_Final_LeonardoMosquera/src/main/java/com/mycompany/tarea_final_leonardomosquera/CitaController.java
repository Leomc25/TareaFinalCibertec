/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.tarea_final_leonardomosquera;

import ClasesDAO.CitaDAO;
import ClasesDAO.MedicoDAO;
import ClasesDAO.PacienteDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import Entidades.*;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

/**
 *
 * @author leofr
 */
@WebServlet(name = "CitaController", urlPatterns = {"/CitaController"})
public class CitaController extends HttpServlet {

    private CitaDAO citaDAO = new CitaDAO();
    private MedicoDAO medicoDAO = new MedicoDAO();
    private PacienteDAO pacienteDAO = new PacienteDAO();
    // Formato que combina fecha y hora del input HTML (ej: 2025-10-26T18:30)
    private SimpleDateFormat formatoDateTime = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CitaController</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet CitaController at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        String accion = request.getParameter("accion");
        if (accion == null) accion = "listar";
        
        switch (accion) {
            case "listar":
                listarCitas(request, response);
                break;
            case "mostrarFormRegistro":
                cargarDatosFormulario(request, response); // Carga Medicos y Pacientes
                request.getRequestDispatcher("/CitaJSP/registrarCita.jsp").forward(request, response);
                break;
           case "obtenerCitaParaEditar":
                   obtenerCitaParaEditar(request, response);
                        break;//para edición de citas
            case "eliminar":
                eliminarCita(request, response);
                break;
            default:
                listarCitas(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       // processRequest(request, response);
       String accion = request.getParameter("accion");
        
        if (accion != null) {
            switch (accion) {
                case "registrar":
                    registrarCita(request, response);
                    break;
                case "actualizarCita":
                    actualizarCita(request, response);
            break;
     
            }
        }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void listarCitas(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        List<Cita> lista = citaDAO.listarCitas();
        request.setAttribute("listaCitas", lista);
        request.getRequestDispatcher("/CitaJSP/listarCita.jsp").forward(request, response);
    }
    
    private void cargarDatosFormulario(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Necesario para los ComboBox de Medicos y Pacientes
        List<Medico> listaMedicos = medicoDAO.listarMedicos();
        List<Paciente> listaPacientes = pacienteDAO.listarPacientes();
        
        request.setAttribute("listaMedicos", listaMedicos);
        request.setAttribute("listaPacientes", listaPacientes);
    }

    private void registrarCita(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String mensaje = "Error al registrar cita.";
        try {
            // 1. Obtener datos
            int idpaciente = Integer.parseInt(request.getParameter("idpaciente"));
            int idmedico = Integer.parseInt(request.getParameter("idmedico"));
            String diahoraStr = request.getParameter("diahora"); // Formato 'yyyy-MM-ddTHH:mm'
            
            Date fechaHora = formatoDateTime.parse(diahoraStr); 
            Timestamp fecha_hora = new Timestamp(fechaHora.getTime()); // Conversión a Timestamp para la BD
            
            // 2. Crear objeto y llamar DAO
            Cita c = new Cita();
            c.setIdpaciente(idpaciente);
            c.setIdmedico(idmedico);
            c.setFecha_hora(fecha_hora);
            
            int resultado = citaDAO.registrarCita(c);
            mensaje = (resultado > 0) ? "Cita registrada exitosamente." : mensaje;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // 3. Redireccionar al listado
        response.sendRedirect("CitaController?mensaje=" + mensaje);
    }
    
    private void eliminarCita(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int id = Integer.parseInt(request.getParameter("id"));
        int resultado = citaDAO.eliminarCita(id);
        
        String mensaje = (resultado > 0) ? "Cita eliminada correctamente." : "Error: No se pudo eliminar la cita.";
        
        response.sendRedirect("CitaController?mensaje=" + mensaje);
    }
    
    private void obtenerCitaParaEditar(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    try {
        int id = Integer.parseInt(request.getParameter("id"));
        
        Cita cita = citaDAO.obtenerCita(id);
        
        // Las listas ya están disponibles a través de los DAO (instanciados al inicio)
        List<Medico> listaMedicos = medicoDAO.listarMedicos();
        List<Paciente> listaPacientes = pacienteDAO.listarPacientes();

        request.setAttribute("cita", cita);
        request.setAttribute("listaMedicos", listaMedicos);
        request.setAttribute("listaPacientes", listaPacientes);

        // Envía los datos al nuevo JSP
        request.getRequestDispatcher("/CitaJSP/editarCita.jsp").forward(request, response);
    } catch (NumberFormatException e) {
        response.sendRedirect("CitaController?accion=listar&mensaje=Error: ID de cita no válido para edición.");
    }
    }
    
    
    private void actualizarCita(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    
    String mensaje = "Error al actualizar la cita.";
    try {
        // 1. Obtener datos, incluyendo el ID de la cita a editar
        int idcita = Integer.parseInt(request.getParameter("idcita")); // Viene del campo hidden
        int idpaciente = Integer.parseInt(request.getParameter("idpacientes")); 
        int idmedico = Integer.parseInt(request.getParameter("idmedicos")); 
        String diahoraStr = request.getParameter("fecha_hora"); // Formato 'yyyy-MM-ddTHH:mm'
        
        // El formatoDateTime debe manejar "yyyy-MM-ddTHH:mm"
        // Si el formato es solo "yyyy-MM-dd'T'HH:mm", no debería fallar.
        Date fechaHora = formatoDateTime.parse(diahoraStr); 
        Timestamp fecha_hora = new Timestamp(fechaHora.getTime());
        
        // 2. Crear objeto Cita
        Cita c = new Cita();
        c.setIdcita(idcita); // ¡CRÍTICO! Para el WHERE de la actualización
        c.setIdpaciente(idpaciente);
        c.setIdmedico(idmedico);
        c.setFecha_hora(fecha_hora);
        
        // 3. Actualizar
        int resultado = citaDAO.actualizarCita(c);
        mensaje = (resultado > 0) ? "Cita actualizada exitosamente." : mensaje;
        
    } catch (Exception e) {
        e.printStackTrace();
        mensaje = "Error fatal al procesar la actualización: " + e.getMessage();
    }
    
    // 4. Redireccionar al listado
    response.sendRedirect("CitaController?mensaje=" + mensaje);
}
}
