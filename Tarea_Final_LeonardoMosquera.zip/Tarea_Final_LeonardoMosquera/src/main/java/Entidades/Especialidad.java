/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author leofr
 */
public class Especialidad {
    private int idespecialidades;
    private String especialidad;

    public Especialidad() {
    }

    public Especialidad(int idespecialidad, String especialidad) {
        this.idespecialidades = idespecialidad;
        this.especialidad = especialidad;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public int getIdespecialidad() {
        return idespecialidades;
    }

    public void setIdespecialidad(int idespecialidad) {
        this.idespecialidades = idespecialidad;
    }
    
    
    
}
