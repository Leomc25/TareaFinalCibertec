/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author leofr
 */
public class Medico {
    private int idmedico;
    private String nombres;
    private int idespecialidad;
    
    private Especialidad objEspecialidad;

    public Medico() {
    }

    public Medico(int idmedico, String nombres, int idespecialidad, Especialidad objEspecialidad) {
        this.idmedico = idmedico;
        this.nombres = nombres;
        this.idespecialidad = idespecialidad;
        this.objEspecialidad = objEspecialidad;
    }

    public int getIdmedico() {
        return idmedico;
    }

    public void setIdmedico(int idmedico) {
        this.idmedico = idmedico;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public int getIdespecialidad() {
        return idespecialidad;
    }

    public void setIdespecialidad(int idespecialidad) {
        this.idespecialidad = idespecialidad;
    }

    public Especialidad getObjEspecialidad() {
        return objEspecialidad;
    }

    public void setObjEspecialidad(Especialidad objEspecialidad) {
        this.objEspecialidad = objEspecialidad;
    }
    
    @Override
    public String toString(){
        return "Medico{" +
                "idmedico=" + idmedico + 
                ",nombre='" + nombres   + '\'' +
                ",idespecialidad=" + idespecialidad +
                ", especialidad=" + (objEspecialidad !=null ? objEspecialidad.getEspecialidad() : "N/A")+
                '}';
        
        
    }
    
}
