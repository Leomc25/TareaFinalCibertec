/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;


import java.util.Date;

/**
 *
 * @author leofr
 */
public class Paciente {
    private int idpacientes;
    private String nombre;
    private Date nacimiento;

    public Paciente() {
    }

    public Paciente(int idpaciente, String nombre, Date nacimiento) {
        this.idpacientes = idpaciente;
        this.nombre = nombre;
        this.nacimiento = nacimiento;
    }

    public Date getNacimiento() {
        return nacimiento;
    }

    public void setNacimiento(Date nacimiento) {
        this.nacimiento = nacimiento;
    }

    public int getIdpaciente() {
        return idpacientes;
    }

    public void setIdpaciente(int idpaciente) {
        this.idpacientes = idpaciente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
    
}
