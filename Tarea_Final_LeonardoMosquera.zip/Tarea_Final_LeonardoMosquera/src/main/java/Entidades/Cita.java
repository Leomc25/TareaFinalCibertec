/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;
import java.sql.Timestamp; // Usaremos Timestamp para mapear DATETIME
/**
 *
 * @author leofr
 */
public class Cita {
    
    private int idcita;
    private Timestamp fecha_hora;
    
    // Claves foráneas representadas como objetos
    private Paciente objPaciente; // Relación con Paciente
    private Medico objMedico; // Relación con Medico
    
    //Claves foráneas directas
    private int idpaciente;
    private int idmedico;

    public Cita() {
    }

    public Cita(int idcita, Timestamp fecha_hora, Paciente objPaciente, Medico objMedico, int idpaciente, int idmedico) {
        this.idcita = idcita;
        this.fecha_hora = fecha_hora;
        this.objPaciente = objPaciente;
        this.objMedico = objMedico;
        this.idpaciente = idpaciente;
        this.idmedico = idmedico;
    }

    public int getIdmedico() {
        return idmedico;
    }

    public void setIdmedico(int idmedico) {
        this.idmedico = idmedico;
    }

    public int getIdcita() {
        return idcita;
    }

    public void setIdcita(int idcita) {
        this.idcita = idcita;
    }

    public Timestamp getFecha_hora() {
        return fecha_hora;
    }

    public void setFecha_hora(Timestamp fecha_hora) {
        this.fecha_hora = fecha_hora;
    }

    public Paciente getObjPaciente() {
        return objPaciente;
    }

    public void setObjPaciente(Paciente objPaciente) {
        this.objPaciente = objPaciente;
    }

    public Medico getObjMedico() {
        return objMedico;
    }

    public void setObjMedico(Medico objMedico) {
        this.objMedico = objMedico;
    }

    public int getIdpaciente() {
        return idpaciente;
    }

    public void setIdpaciente(int idpaciente) {
        this.idpaciente = idpaciente;
    }
    
    
    
    
}
