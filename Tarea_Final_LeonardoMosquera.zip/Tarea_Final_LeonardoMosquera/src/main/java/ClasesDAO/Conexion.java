/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    // Configuración de la conexión a MySQL
    private static final String URL = "jdbc:mysql://localhost:3306/CitasMedicas?serverTimezone=UTC";
    private static final String USER = "root";  //usuario
    private static final String PASSWORD = "leonardo"; //  contraseña
    
    public static Connection getConnection() {
        Connection cn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            cn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            // Este error significa que el JAR del driver no está bien enlazado.
            throw new RuntimeException("Error: Driver MySQL no encontrado. Verifique WEB-INF/lib.", e);
        } catch (SQLException e) {
            // ¡ESTA LÍNEA REVELARÁ EL ERROR!
            // Si la conexión falla, forzamos una excepción con el mensaje de SQL.
            System.err.println("Error de conexión SQL: " + e.getMessage());
            // Lanza una excepción que sí llegará al navegador con el mensaje de SQL
            throw new RuntimeException("Fallo al conectar a la BD. Verifique el servidor, puerto o credenciales. Causa: " + e.getMessage(), e);
        }
        return cn;
    }
    public static void close(Connection cn){
        if(cn!=null){
            try{
                cn.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }
    
    
    
}
