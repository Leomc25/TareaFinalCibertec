/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Entidades.*;

public class EspecialidadDAO {
    public List<Especialidad> listarEspecialidades() {
        List<Especialidad> lista = new ArrayList<>();
        Connection cn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "SELECT idespecialidades, especialidad FROM especialidades ORDER BY especialidad";
            pstm = cn.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            while(rs.next()) {
                Especialidad e = new Especialidad();
                e.setIdespecialidad(rs.getInt("idespecialidades"));
                e.setEspecialidad(rs.getString("especialidad"));
                lista.add(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS: rs -> pstm -> cn
            try {
                if (rs != null) rs.close();
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return lista;
    }
    
    // ------------------- R: Obtener por ID -------------------
    public Especialidad obtenerEspecialidad(int id) {
        Especialidad e = null;
        Connection cn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "SELECT idespecialidades, especialidad FROM especialidades WHERE idespecialidades = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, id);
            rs = pstm.executeQuery();
            
            if (rs.next()) {
                e = new Especialidad();
                e.setIdespecialidad(rs.getInt("idespecialidades"));
                e.setEspecialidad(rs.getString("especialidad"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS: rs -> pstm -> cn
            try {
                if (rs != null) rs.close();
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return e;
    }

    // ------------------- C: Crear (Insertar) -------------------
    public int insertarEspecialidad(Especialidad e) {
        int estado = -1;
        Connection cn = null;
        PreparedStatement pstm = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "INSERT INTO especialidades (especialidad) VALUES (?)";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, e.getEspecialidad());
            
            estado = pstm.executeUpdate();
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS: pstm -> cn
            try {
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return estado;
    }

    // ------------------- U: Actualizar -------------------
    public int actualizarEspecialidad(Especialidad e) {
        int estado = -1;
        Connection cn = null;
        PreparedStatement pstm = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "UPDATE especialidades SET especialidad = ? WHERE idespecialidades = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, e.getEspecialidad());
            pstm.setInt(2, e.getIdespecialidad());
            
            estado = pstm.executeUpdate();
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS: pstm -> cn
            try {
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return estado;
    }

    // ------------------- D: Eliminar -------------------
    public int eliminarEspecialidad(int id) {
        int estado = -1;
        Connection cn = null;
        PreparedStatement pstm = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "DELETE FROM especialidades WHERE idespecialidades = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, id);
            
            estado = pstm.executeUpdate();
            
        } catch (SQLException ex) {
            // Manejo de la excepción si hay médicos asociados (FK)
            ex.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS: pstm -> cn
            try {
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return estado;
    }
    
}
