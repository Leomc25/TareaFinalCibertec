/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesDAO;

import Entidades.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MedicoDAO {
    // ------------------- R: Obtener Todos (Listar) -------------------
    public List<Medico> listarMedicos() {
        List<Medico> lista = new ArrayList<>();
        Connection cn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        
        try {
            cn = Conexion.getConnection();
            // JOIN necesario para obtener el nombre de la especialidad
            String sql = "SELECT m.idmedicos, m.nombres, m.idespecialidades, e.especialidad " +
                         "FROM medicos m JOIN especialidades e ON m.idespecialidades = e.idespecialidades " +
                         "ORDER BY m.nombres";
            pstm = cn.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            while(rs.next()) {
                Medico m = new Medico();
                m.setIdmedico(rs.getInt("idmedicos"));
                m.setNombres(rs.getString("nombres"));
                m.setIdespecialidad(rs.getInt("idespecialidades"));
                
                // Creación del objeto Especialidad para la relación
                Especialidad e = new Especialidad();
                e.setIdespecialidad(rs.getInt("idespecialidades"));
                e.setEspecialidad(rs.getString("especialidad"));
                
                m.setObjEspecialidad(e);
                lista.add(m);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS
            try {
                if (rs != null) rs.close();
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return lista;
    }

    // ------------------- R: Obtener por ID -------------------
    public Medico obtenerMedico(int id) {
        Medico m = null;
        Connection cn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        
        try {
            cn = Conexion.getConnection();
            // Se recuperan los IDs y nombres principales
            String sql = "SELECT idmedicos, nombres, idespecialidades FROM medicos WHERE idmedicos = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, id);
            rs = pstm.executeQuery();
            
            if (rs.next()) {
                m = new Medico();
                m.setIdmedico(rs.getInt("idmedicos"));
                m.setNombres(rs.getString("nombres"));
                m.setIdespecialidad(rs.getInt("idespecialidades"));
                
                // El objeto Especialidad se puede cargar aquí o se deja nulo/vacío, 
                // ya que normalmente solo se necesita el ID para la edición en el formulario.
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS
            try {
                if (rs != null) rs.close();
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return m;
    }
    
    // ------------------- C: Crear (Insertar) -------------------
    public int insertarMedico(Medico m) {
        int estado = -1;
        Connection cn = null;
        PreparedStatement pstm = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "INSERT INTO medicos (nombres, idespecialidades) VALUES (?, ?)";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, m.getNombres());
            pstm.setInt(2, m.getIdespecialidad());
            
            estado = pstm.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS
            try {
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return estado;
    }
    
    // ------------------- U: Actualizar -------------------
    public int actualizarMedico(Medico m) {
        int estado = -1;
        Connection cn = null;
        PreparedStatement pstm = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "UPDATE medicos SET nombres = ?, idespecialidades = ? WHERE idmedicos = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, m.getNombres());
            pstm.setInt(2, m.getIdespecialidad());
            pstm.setInt(3, m.getIdmedico());
            
            estado = pstm.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS
            try {
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return estado;
    }
    
    // ------------------- D: Eliminar -------------------
    public int eliminarMedico(int id) {
        int estado = -1;
        Connection cn = null;
        PreparedStatement pstm = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "DELETE FROM medicos WHERE idmedicos = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, id);
            
            estado = pstm.executeUpdate();
            
        } catch (SQLException e) {
            // Manejo de la excepción si hay citas asociadas (FK)
            e.printStackTrace(); 
        } finally {
            // CIERRE DE RECURSOS
            try {
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return estado;
    }
}
