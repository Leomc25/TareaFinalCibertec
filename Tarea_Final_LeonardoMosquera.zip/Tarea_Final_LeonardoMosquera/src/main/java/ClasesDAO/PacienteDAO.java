/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesDAO;

import Entidades.Paciente;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO {
    
    public List<Paciente> listarPacientes() {
        List<Paciente> lista = new ArrayList<>();
        Connection cn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "SELECT idpacientes, nombre, nacimiento FROM pacientes ORDER BY nombre";
            pstm = cn.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            while(rs.next()) {
                Paciente p = new Paciente();
                p.setIdpaciente(rs.getInt("idpacientes"));
                p.setNombre(rs.getString("nombre"));
                // Mapeo del campo DATE
                p.setNacimiento(rs.getDate("nacimiento")); 
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
             try {
                if (rs != null) rs.close();
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
            
            
            
        }
        return lista;
    }
    
    public Paciente obtenerPaciente(int id) {
        Paciente p = null;
        Connection cn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "SELECT idpacientes, nombre, nacimiento FROM pacientes WHERE idpacientes = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, id);
            rs = pstm.executeQuery();
            
            if (rs.next()) {
                p = new Paciente();
                p.setIdpaciente(rs.getInt("idpacientes"));
                p.setNombre(rs.getString("nombre"));
                p.setNacimiento(rs.getDate("nacimiento"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return p;
    }
    
    public int insertarPaciente(Paciente p) {
        int estado = -1;
        Connection cn = null;
        PreparedStatement pstm = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "INSERT INTO pacientes (nombre, nacimiento) VALUES (?, ?)";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, p.getNombre());
            // Conversión de java.util.Date a java.sql.Date
            pstm.setDate(2, new Date(p.getNacimiento().getTime())); 
            
            estado = pstm.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
             try {
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return estado;
    }
    public int actualizarPaciente(Paciente p) {
        int estado = -1;
        Connection cn = null;
        PreparedStatement pstm = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "UPDATE pacientes SET nombre = ?, nacimiento = ? WHERE idpacientes = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, p.getNombre());
            pstm.setDate(2, new Date(p.getNacimiento().getTime()));
            pstm.setInt(3, p.getIdpaciente());
            
            estado = pstm.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return estado;
    }
    
    public int eliminarPaciente(int id) {
        int estado = -1;
        Connection cn = null;
        PreparedStatement pstm = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "DELETE FROM pacientes WHERE idpacientes = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, id);
            
            estado = pstm.executeUpdate();
            
        } catch (SQLException e) {
            // Si hay citas asociadas, MySQL lanzará una excepción por FK (Integridad referencial)
            e.printStackTrace();
        } finally {
             try {
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return estado;
    }
    
    
    
}
