/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesDAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Entidades.*;


public class CitaDAO {
    public List<Cita> listarCitas() {
        List<Cita> lista = new ArrayList<>();
        Connection cn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        
        try {
            cn = Conexion.getConnection();
            // SQL: 3 JOINs para obtener toda la información
            String sql = "SELECT c.idcitas, c.fecha_hora, " +
                         "p.idpacientes, p.nombre AS nombre_paciente, " +
                         "m.idmedicos, m.nombres AS nombre_medico, " +
                         "e.idespecialidades, e.especialidad " +
                         "FROM citas c " +
                         "JOIN pacientes p ON c.idpacientes = p.idpacientes " +
                         "JOIN medicos m ON c.idmedicos = m.idmedicos " +
                         "JOIN especialidades e ON m.idespecialidades = e.idespecialidades " +
                         "ORDER BY c.fecha_hora DESC";
            
            pstm = cn.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            while(rs.next()) {
                Cita c = new Cita();
                c.setIdcita(rs.getInt("idcitas"));
                c.setFecha_hora(rs.getTimestamp("fecha_hora"));
                
                // Mapeo de Objetos Relacionados
                Paciente p = new Paciente();
                p.setIdpaciente(rs.getInt("idpacientes"));
                p.setNombre(rs.getString("nombre_paciente"));
                c.setObjPaciente(p);
                
                Especialidad e = new Especialidad();
                e.setIdespecialidad(rs.getInt("idespecialidades"));
                e.setEspecialidad(rs.getString("especialidad"));
                
                Medico m = new Medico();
                m.setIdmedico(rs.getInt("idmedicos"));
                m.setNombres(rs.getString("nombre_medico"));
                m.setObjEspecialidad(e); 
                c.setObjMedico(m);
                
                lista.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS
            try {
                if (rs != null) rs.close();
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return lista;
    }
    
    public Cita obtenerCita(int id) {
        // Para simplificar, solo recuperaremos los IDs necesarios para la edición.
        Cita c = null;
        Connection cn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "SELECT idcitas, idpacientes, idmedicos, fecha_hora FROM citas WHERE idcitas = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, id);
            rs = pstm.executeQuery();
            
            if (rs.next()) {
                c = new Cita();
                c.setIdcita(rs.getInt("idcitas"));
                c.setIdpaciente(rs.getInt("idpacientes"));
                c.setIdmedico(rs.getInt("idmedicos"));
                c.setFecha_hora(rs.getTimestamp("fecha_hora"));
                
              
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS
            try {
                if (rs != null) rs.close();
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return c; 
    }
    
    public int registrarCita(Cita c) {
        int estado = -1;
        Connection cn = null;
        PreparedStatement pstm = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "INSERT INTO citas (idpacientes, idmedicos, fecha_hora) VALUES (?, ?, ?)";
            pstm = cn.prepareStatement(sql);
            
            pstm.setInt(1, c.getIdpaciente());
            pstm.setInt(2, c.getIdmedico());
            pstm.setTimestamp(3, c.getFecha_hora()); 
            
            estado = pstm.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS
            try {
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return estado;
    }
    
    public int actualizarCita(Cita c) {
        int estado = -1;
        Connection cn = null;
        PreparedStatement pstm = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "UPDATE citas SET idpacientes = ?, idmedicos = ?, fecha_hora = ? WHERE idcitas = ?";
            pstm = cn.prepareStatement(sql);
            
            pstm.setInt(1, c.getIdpaciente());
            pstm.setInt(2, c.getIdmedico());
            pstm.setTimestamp(3, c.getFecha_hora());
            pstm.setInt(4, c.getIdcita());
            
            estado = pstm.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS
            try {
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return estado;
    }
    
    public int eliminarCita(int id) {
        int estado = -1;
        Connection cn = null;
        PreparedStatement pstm = null;
        
        try {
            cn = Conexion.getConnection();
            String sql = "DELETE FROM citas WHERE idcitas = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, id);
            
            estado = pstm.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // CIERRE DE RECURSOS
            try {
                if (pstm != null) pstm.close();
                if (cn != null) cn.close();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        return estado;
    }
    
}
