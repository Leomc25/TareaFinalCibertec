create database if not exists CitasMedicas;
use CitasMedicas;

create table especialidades(
idespecialidades int not null auto_increment,
especialidad varchar(50) not null,
primary key (idespecialidades)
);

create table medicos(
idmedicos int not null auto_increment,
nombres varchar(50) not null,
idespecialidades int not null,
primary key(idmedicos)
);

create table citas(
idcitas int not null auto_increment,
fecha_hora datetime not null,
idpacientes int not null,
idmedicos int not null,

primary key(idcitas)
);

create table pacientes(
idpacientes int not null auto_increment,
nombre varchar(50) not null,
nacimiento date,
primary key(idpacientes)
);

-- 1. Relación: medicos (N) con especialidades (1)
ALTER TABLE medicos
ADD CONSTRAINT fk_medicos_especialidades
FOREIGN KEY (idespecialidades)
REFERENCES especialidades (idespecialidades)
ON DELETE RESTRICT -- Evita borrar una especialidad si hay médicos asociados
ON UPDATE CASCADE; -- Actualiza el ID en 'medicos' si cambia en 'especialidades'


-- 2. Relación: citas (N) con pacientes (1)
ALTER TABLE citas
ADD CONSTRAINT fk_citas_pacientes
FOREIGN KEY (idpacientes)
REFERENCES pacientes (idpacientes)
ON DELETE RESTRICT
ON UPDATE CASCADE;


-- 3. Relación: citas (N) con medicos (1)
ALTER TABLE citas
ADD CONSTRAINT fk_citas_medicos
FOREIGN KEY (idmedicos)
REFERENCES medicos (idmedicos)
ON DELETE RESTRICT
ON UPDATE CASCADE;

INSERT INTO especialidades (idespecialidades, especialidad) VALUES
(1, 'Cardiología'),
(2, 'Pediatría'),
(3, 'Dermatología'),
(4, 'Oftalmología'),
(5, 'Ginecología');

INSERT INTO pacientes (idpacientes, nombre, nacimiento) VALUES
(1, 'Ana Pérez López', '1985-05-15'),
(2, 'Juan Gómez Torres', '2010-02-20'), -- Niño
(3, 'Sofía Castro Ruiz', '1992-11-30'),
(4, 'Carlos Rivera Díaz', '1978-08-01'),
(5, 'Laura Martínez Gil', '2005-03-25'),
(6, 'Miguel Ángel Soto', '1965-12-10'),
(7, 'Elena Vargas Morales', '1998-07-07'),
(8, 'David Herrera León', '2015-09-03'), -- Niño
(9, 'Fátima Nájera P.', '1989-04-18'),
(10, 'Ricardo Mendiola A.', '1972-01-22');

INSERT INTO medicos (idmedicos, nombres, idespecialidades) VALUES
(101, 'Dr. Alberto Nuñez', 1), -- Cardiología
(102, 'Dra. Isabel Flores', 2), -- Pediatría
(103, 'Dr. Javier Rivas', 3),   -- Dermatología
(104, 'Dra. Patricia Soler', 4), -- Oftalmología
(105, 'Dra. Andrea Lemos', 5),   -- Ginecología
(106, 'Dr. Gonzalo Tello', 1);   -- Otro Cardiólogo

INSERT INTO citas (idcitas, fecha_hora, idpacientes, idmedicos) VALUES
(1, '2024-10-28 09:00:00', 1, 101), -- Ana (Cardiología)
(2, '2024-10-28 10:30:00', 2, 102), -- Juan (Pediatría)
(3, '2024-10-29 14:00:00', 3, 103), -- Sofía (Dermatología)
(4, '2024-10-29 11:00:00', 4, 104), -- Carlos (Oftalmología)
(5, '2024-10-30 08:00:00', 5, 105), -- Laura (Ginecología)
(6, '2024-10-30 15:30:00', 6, 106), -- Miguel (Cardiología)
(7, '2024-10-31 09:30:00', 7, 101), -- Elena (Cardiología)
(8, '2024-11-01 16:00:00', 8, 102), -- David (Pediatría)
(9, '2024-11-02 10:00:00', 9, 103), -- Fátima (Dermatología)
(10, '2024-11-02 11:30:00', 10, 104); -- Ricardo (Oftalmología)

select * from citas;
select * from especialidades;
select * from medicos;
select * from pacientes;
